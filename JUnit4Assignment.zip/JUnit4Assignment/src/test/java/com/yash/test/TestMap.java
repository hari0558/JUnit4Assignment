package com.yash.test;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.hamcrest.Matcher;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestMap {
	private Map<Integer,Integer>map;

	@Before
	public void setUp() throws Exception {
		map=new HashMap<Integer,Integer>();
	map.put(1001,232425);
	map.put(1020, 213431);
	map.put(-1001, -10000);
	map.put(-1050, 543);
	map.put(1040, 5634);
	}

	@After
	public void tearDown() throws Exception {
		map=null;
		
	}

	@Test
	public void testMapContainsPerticularKeyAndValue() {
		assertThat(map,hasEntry(-1001, -10000));
	}

	private Matcher<? super Map<Integer, Integer>> hasEntry(int i, int j) {
		
		return null;
	}

}
