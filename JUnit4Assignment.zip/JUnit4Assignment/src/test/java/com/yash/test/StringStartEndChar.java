package com.yash.test;

import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.junit.Assert.*;

import org.junit.Test;

public class StringStartEndChar {
	
	@Test
	public void testStringStartWith_S_And_EndsWith_h() {
		String str="Some questions with answers was tough";
		assertThat(str,startsWith("S"));
		assertThat(str,endsWith("h"));
	}

}
